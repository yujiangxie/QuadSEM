Yujiang Xie

1. here the framework of xsmooth_sem can be used as a framework for preconditioner for sources and receivers. 
2. xsmooth_sem_original is the orignal xsmooth_sem file.
3. xsmooth_sem_precond is the preconditioners for sources and receivers, which need to read the coordinates of the sources and receivers into the codes.



