# External libraries

This folder holds the dependencies on external libraries.

For further informations, see:

- [Scotch](https://gforge.inria.fr/projects/scotch/)
- [LibJPEG](http://www.ijg.org/)

